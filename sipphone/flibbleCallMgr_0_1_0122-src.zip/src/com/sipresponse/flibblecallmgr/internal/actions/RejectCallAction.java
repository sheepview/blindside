package com.sipresponse.flibblecallmgr.internal.actions;

public class RejectCallAction
{

}
